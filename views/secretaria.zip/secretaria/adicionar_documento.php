
        <div class="main-wrapper">
            <form method="POST">
                <div class="row">
                    <div class="col-xl">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">Adicionar Documentos </h5>
                                <p>Area destinada ao cadastro de documentos. </p>
                                
                                <div class="form-row">
                                    <div class="form-group col-md-12">
                                        <label for="exampleInputEmail1">Titulo:</label>
                                        <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="titulo">
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                

                <button type="submit" class="btn btn-primary">Cadastrar Documento</button>

            </form>
            
        </div>
    </div>
